@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Structure_Type\MDSYS.SDO_GEOMETRY.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Structure_Type\XMLTYPE.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Table\Driver.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Table\Driver_Constraints.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Table\JobSheet.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Table\JobSheet_Constraints.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Table\  Location.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Table\  Location_Constraints.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Table\Trip.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Table\Trip_Constraints.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Table\Vehicle.sql
@@pat_logical\Relational_1\Oracle_Database_11g\DataObjects\Table\Vehicle_Constraints.sql
