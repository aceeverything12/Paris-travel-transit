CREATE TABLE jobsheet (
    sheetid                 unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
     NOT NULL,
    "Trip ID"               unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "Driver ID"             unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "Booked For"            unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "Number of Passengers"  unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "Pickup Location ID"    unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "Actual pickup Time"    unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "DropOff Location ID"   unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "Droff Off Actual Time" unknown 
--  ERROR: Datatype UNKNOWN is not allowed 

);