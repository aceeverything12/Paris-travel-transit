CREATE TABLE vehicle (
    make      mdsys.sdo_geometry,
    model     unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    year      unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    vehicleid unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
     NOT NULL
);