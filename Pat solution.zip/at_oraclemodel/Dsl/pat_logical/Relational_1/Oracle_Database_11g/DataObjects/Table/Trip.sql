CREATE TABLE trip (
    "Trip ID"    unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
     NOT NULL,
    "Vehicle ID" unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "Driver ID"  unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "Booked For" unknown 
--  ERROR: Datatype UNKNOWN is not allowed 

);