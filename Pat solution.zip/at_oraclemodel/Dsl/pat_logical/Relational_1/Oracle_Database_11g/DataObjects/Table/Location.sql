CREATE TABLE "  Location" (
    "Location ID" unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
     NOT NULL,
    name          unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    type          unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    address       unknown 
--  ERROR: Datatype UNKNOWN is not allowed 

);