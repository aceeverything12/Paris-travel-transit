CREATE TABLE driver (
    "Driver ID"    unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
     NOT NULL,
    name           unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "Security Clr" unknown 
--  ERROR: Datatype UNKNOWN is not allowed 
    ,
    "Expiry datw"  unknown 
--  ERROR: Datatype UNKNOWN is not allowed 

);